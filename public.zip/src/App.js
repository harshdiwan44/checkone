import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Ap from "./components/DropdownList";

export default function App() {
  return (
    <div className="container mt-2">
      <Ap />
    </div>
  );
}
